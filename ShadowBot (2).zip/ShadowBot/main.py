import discord
from discord.ext import commands
from discord.ui import View, Select
import asyncio
import os
import random
import requests
from googletrans import Translator
import yt_dlp as youtube_dl
from discord import FFmpegPCMAudio
import ctypes
import ctypes.util

# Essayer de charger la bibliothèque Opus
try:
    opus_lib = ctypes.util.find_library('opus')
    if opus_lib:
        discord.opus.load_opus(opus_lib)
        print(f"Opus chargé automatiquement depuis {opus_lib}")
    else:
        from glob import glob
        from subprocess import run, PIPE

        find_cmd = run(["find", "/nix/store", "-name", "libopus.so*"], stdout=PIPE, text=True)
        opus_paths = find_cmd.stdout.strip().split('\n')
        opus_paths.extend([
            '/usr/lib/x86_64-linux-gnu/libopus.so.0',
            '/usr/lib/libopus.so.0',
            '/lib/libopus.so.0'
        ])
        loaded = False
        for path in opus_paths:
            if not path:
                continue
            try:
                discord.opus.load_opus(path)
                print(f"✅ Opus chargé avec succès depuis {path}")
                loaded = True
                break
            except Exception as e:
                print(f"Échec du chargement d'Opus depuis {path}: {str(e)}")

        if not loaded:
            print("⚠️ AVERTISSEMENT: Impossible de charger la bibliothèque Opus.")
except Exception as e:
    print(f"⚠️ Erreur lors du chargement d'Opus: {str(e)}")
    print("La qualité audio peut être affectée.")

# Configuration du bot
intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="+", intents=intents)

# Fonction pour envoyer un message temporaire
async def send_temporary_message(ctx, content):
    """Envoie un message temporaire qui disparaît après 5 secondes."""
    message = await ctx.send(content)
    await asyncio.sleep(5)
    await message.delete()

# Event : Bot prêt
@bot.event
async def on_ready():
    print(f'Connecté en tant que {bot.user}')

# Classe pour le sélecteur d'aide
class AideSelect(Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="Modération", description="⚖️ Commandes de gestion des membres", emoji="⚖️"),
            discord.SelectOption(label="Fun", description="🎉 Commandes amusantes", emoji="🎉"),
            discord.SelectOption(label="Info", description="ℹ️ Obtenir des informations", emoji="ℹ️"),
            discord.SelectOption(label="Utilitaire", description="🔧 Commandes pratiques", emoji="🔧"),
            discord.SelectOption(label="Musique", description="🎶 Commandes musicales", emoji="🎶"),
            discord.SelectOption(label="Tickets", description="🎫 Gestion des tickets", emoji="🎫"),
            discord.SelectOption(label="Bienvenue", description="👋 Messages de bienvenue", emoji="👋")
        ]
        super().__init__(placeholder="Choisissez une catégorie...", options=options)

    async def callback(self, interaction: discord.Interaction):
        category = self.values[0]
        embed = discord.Embed(title=f"{category} Commands", color=discord.Color.green())

        if category == "Modération":
            embed.add_field(name="⚖️ Modération", value=(
                "⚔️ ban [utilisateur] - Bannir un utilisateur.\n"
                "🚪 kick [utilisateur] - Expulser un utilisateur.\n"
                "🔇 mute [utilisateur] [durée] - Mute un utilisateur pour un temps donné.\n"
                "🔊 unmute [utilisateur] - Unmute un utilisateur.\n"
                "🚫 warn [utilisateur] [raison] - Avertir un utilisateur.\n"
                "📜 warns [utilisateur] - Voir les avertissements d'un utilisateur.\n"
                "❌ clearwarns [utilisateur] - Effacer les avertissements d'un utilisateur.\n"
                "🧹 clear [nombre] - Effacer un nombre de messages.\n"
                "🔐 lock [salon] - Verrouiller un salon.\n"
                "🔓 unlock [salon] - Déverrouiller un salon."
            ), inline=False)
        elif category == "Fun":
            embed.add_field(name="🎉 Fun", value=(
                "🎱 ball8 [question] - Poser une question à la boule magique.\n"
                "🗣️ say [message] - Faire répéter un message.\n"
                "🔄 reverse [message] - Renverser un message.\n"
                "🎲 dice - Lancer un dé.\n"
                "😂 joke - Obtenir une blague aléatoire.\n"
                "🐸 meme - Obtenir un mème aléatoire.\n"
                "👑 avatar [utilisateur] - Afficher l'avatar d'un utilisateur.\n"
                "🎭 slap [utilisateur] - Donner une gifle virtuelle.\n"
                "🎯 choose [option1] [option2] ... - Choisir entre plusieurs options.\n"
                "🎥 gif [recherche] - Envoyer un GIF correspondant à une recherche."
            ), inline=False)
        elif category == "Info":
            embed.add_field(name="ℹ️ Info", value=(
                "🏠 serverinfo - Obtenir des informations sur le serveur.\n"
                "👤 userinfo [utilisateur] - Obtenir des informations sur un utilisateur.\n"
                "⏰ uptime - Voir depuis combien de temps le bot est en ligne.\n"
                "🌐 ping - Vérifier la latence du bot.\n"
                "📅 date - Voir la date et l'heure actuelles.\n"
                "📊 poll [question] - Créer un sondage.\n"
                "🧑‍⚖️ roleinfo [rôle] - Obtenir des informations sur un rôle.\n"
                "🎖️ rank [utilisateur] - Voir le classement d'un utilisateur.\n"
                "📌 serveurstats - Voir les statistiques du serveur.\n"
                "🔍 whois [utilisateur] - Voir des informations détaillées sur un utilisateur."
            ), inline=False)
        elif category == "Utilitaire":
            embed.add_field(name="🔧 Utilitaire", value=(
                "📊 poll [question] - Créer un sondage.\n"
                "⏰ remindme [temps] [message] - Définir un rappel.\n"
                "📅 timer [temps] - Définir un minuteur.\n"
                "🔎 google [recherche] - Rechercher quelque chose sur Google.\n"
                "🌍 translate [langue] [texte] - Traduire un texte.\n"
                "🖼️ image [recherche] - Rechercher une image sur le web.\n"
                "💡 define [mot] - Obtenir la définition d'un mot.\n"
                "🔗 shorten [URL] - Raccourcir une URL.\n"
                "📩 dm [utilisateur] [message] - Envoyer un message privé à un utilisateur.\n"
                "📝 note [texte] - Prendre une note temporaire."
            ), inline=False)
        elif category == "Musique":
            embed.add_field(name="🎶 Musique", value=(
                "🎧 join - Rejoindre le canal vocal.\n"
                "🎶 play [nom/URL] - Jouer une musique.\n"
                "⏸️ pause - Mettre la musique en pause.\n"
                "⏹️ stop - Arrêter la musique.\n"
                "⏭️ skip - Passer à la musique suivante.\n"
                "🔄 loop - Boucler la musique en cours.\n"
                "🔉 volume [1-100] - Régler le volume.\n"
                "🔊 resume - Reprendre la musique.\n"
                "🧹 clear - Effacer la file d'attente.\n"
                "👋 leave - Quitter le canal vocal."
            ), inline=False)
        elif category == "Tickets":
            embed.add_field(name="🎫 Tickets", value=(
                "🎫 newticket - Créer un nouveau ticket.\n"
                "🎫 closeticket - Fermer le ticket actuel.\n"
                "🎫 transferticket [utilisateur] - Transférer le ticket à un autre utilisateur.\n"
                "🎫 add [message] - Ajouter un message au ticket.\n"
                "🎫 list - Lister les tickets ouverts.\n"
                "🎫 view [id] - Voir un ticket spécifique.\n"
                "🎫 help - Afficher l'aide sur les tickets."
            ), inline=False)
        elif category == "Bienvenue":
            embed.add_field(name="👋 Bienvenue", value=(
                "+bienvenue #salon - Définir le salon pour les messages de bienvenue.\n"
                "+welcomemsg [message] - Définir le message de bienvenue à envoyer."
            ), inline=False)

        await interaction.response.edit_message(embed=embed, view=self.view)

# Commande d'aide pour afficher le sélecteur
@bot.command(name="aide")
async def aide(ctx):
    view = View()


# Commande de nettoyage de messages
@bot.command()
@commands.has_permissions(manage_messages=True)
async def clear(ctx, amount: int):
    """Efface un nombre spécifié de messages dans le canal actuel."""
    await ctx.channel.purge(limit=amount)
    await send_temporary_message(ctx, f"✅ {amount} messages ont été effacés.")

# Commande pour afficher l'avatar d'un utilisateur
@bot.command()
async def avatar(ctx, member: discord.Member = None):
    """Affiche l'avatar d'un utilisateur."""
    if member is None:
        member = ctx.author
    embed = discord.Embed(title=f"Avatar de {member.display_name}", color=discord.Color.blue())
    embed.set_image(url=member.avatar.url)
    await ctx.send(embed=embed)
    await send_temporary_message(ctx, f"✅ Avatar de {member.display_name} affiché.")

# Commande pour rejoindre un canal vocal
@bot.command()
async def join(ctx):
    """Le bot rejoint le canal vocal."""
    if ctx.author.voice is None:
        await send_temporary_message(ctx, "❌ Vous devez être dans un canal vocal.")
        return
    channel = ctx.author.voice.channel
    await channel.connect()
    await send_temporary_message(ctx, "✅ Bot a rejoint le canal vocal.")
# Commande pour quitter le canal vocal
@bot.command()
async def leave(ctx):
    """Le bot quitte le canal vocal."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
    await ctx.voice_client.disconnect()
    await send_temporary_message(ctx, "✅ Bot a quitté le canal vocal.")

# Commande pour régler le volume
@bot.command()
async def volume(ctx, volume: int):
    """Règle le volume de la musique."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
    
    if volume < 0 or volume > 1000:
        await send_temporary_message(ctx, "❌ Le volume doit être compris entre 0 et 1000.")
        return
    
    if not ctx.voice_client.is_playing():
        await send_temporary_message(ctx, "❌ Aucune musique n'est en cours de lecture.")
        return
    
    # Vérifier si la source est bien un PCMVolumeTransformer
    if not hasattr(ctx.voice_client.source, 'volume'):
        await send_temporary_message(ctx, "❌ Impossible de régler le volume pour cette source audio.")
        return
    
    ctx.voice_client.source.volume = volume / 100
    
    # Créer un embed pour afficher le niveau de volume
    embed = discord.Embed(
        title="🔊 Volume",
        description=f"Volume réglé à **{volume}%**",
        color=discord.Color.blue()
    )
    
    # Créer une représentation visuelle du volume
    # Ajuste la représentation pour un maximum de 1000%
    full_blocks = min(10, volume // 100)
    remaining = 10 - full_blocks
    volume_bar = "🟥" * (max(0, full_blocks - 5)) + "🟧" * (min(5, max(0, full_blocks - 5))) + "🟩" * min(5, full_blocks) + "⬜" * remaining
    
    embed.add_field(name="Niveau", value=volume_bar)
    
    # Ajouter un avertissement si le volume est élevé
    if volume > 300:
        embed.add_field(name="⚠️ Attention", value="Volume très élevé pouvant causer des distorsions audio importantes.", inline=False)
    elif volume > 100:
        embed.add_field(name="⚠️ Note", value="Volume élevé pouvant causer des distorsions audio.", inline=False)
    
    await ctx.send(embed=embed)
# Commande pour jouer de la musique
@bot.command()
async def play(ctx, url: str):
    """Joue de la musique depuis une URL."""
    if ctx.voice_client is None:
        if ctx.author.voice:
            await ctx.author.voice.channel.connect()
        else:
            await send_temporary_message(ctx, "❌ Vous devez être dans un canal vocal.")
            return

    await send_temporary_message(ctx, "🔍 Recherche de la musique...")

    # Options pour youtube-dl avec un format audio adapté
    ydl_opts = {
        'format': 'bestaudio/best',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'noplaylist': True,
        'quiet': True,
        'no_warnings': True,
        'default_search': 'auto',
        'source_address': '0.0.0.0'  # Liaison à toutes les interfaces réseau
    }

    # Options améliorées pour FFmpeg
    ffmpeg_options = {
        'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5 -nostdin',
        'options': '-vn -af "volume=0.5"'
    }

    try:
        print(f"Tentative de lecture de l'URL: {url}")
        with youtube_dl.YoutubeDL(ydl_opts) as ydl:
            print("Extraction des informations...")
            info = ydl.extract_info(url, download=False)
            
            if 'entries' in info:
                # Si c'est une playlist, prendre le premier élément
                info = info['entries'][0]
            
            # Afficher les formats disponibles
            print(f"Formats disponibles: {len(info['formats'])}")
            for i, format in enumerate(info['formats']):
                print(f"Format {i}: {format.get('format_id')} - {format.get('ext')} - {format.get('format')}")
            
            # Choisir le meilleur format audio
            formats = [f for f in info['formats'] if f.get('acodec') != 'none']
            if formats:
                # Trier par qualité audio (basée sur le bitrate si disponible)
                formats.sort(key=lambda x: int(x.get('abr', 0)) if x.get('abr') else 0, reverse=True)
                url2 = formats[0]['url']
                print(f"Format audio choisi: {formats[0].get('format_id')} - {formats[0].get('ext')} - {formats[0].get('format')}")
            else:
                # Fallback sur le premier format si aucun format audio n'est trouvé
                url2 = info['formats'][0]['url']
                print(f"Aucun format audio pur trouvé, utilisation du format: {info['formats'][0].get('format_id')}")
            
            title = info.get('title', 'Musique inconnue')
            print(f"Titre: {title}")
            print(f"URL audio: {url2[:50]}...")  # Afficher une partie de l'URL pour débogage
            
            # Créer la source audio avec les options FFmpeg
            print("Création de la source audio avec FFmpeg...")
            source = discord.FFmpegPCMAudio(url2, **ffmpeg_options)
            
            # Ajouter un volume contrôlable
            source = discord.PCMVolumeTransformer(source, volume=0.5)
            
            # Jouer la musique
            print("Lecture de la musique...")
            if ctx.voice_client.is_playing():
                ctx.voice_client.stop()
                
            ctx.voice_client.play(source, after=lambda e: print(f'Lecture terminée ou erreur: {e}' if e else 'Lecture terminée avec succès'))
            
            # Créer un embed pour la musique en cours
            embed = discord.Embed(
                title="🎵 Lecture en cours",
                description=f"**{title}**",
                color=discord.Color.green()
            )
            embed.add_field(name="Volume", value="50%", inline=True)
            embed.add_field(name="Format", value=formats[0].get('format', 'Inconnu') if formats else 'Inconnu', inline=True)
            embed.set_footer(text=f"Demandé par {ctx.author.display_name}")
            
            await ctx.send(embed=embed)
            
    except Exception as e:
        error_message = f"❌ Une erreur s'est produite: {str(e)}"
        await ctx.send(error_message)
        print(f"Erreur de lecture: {str(e)}")
        import traceback
        traceback.print_exc()

# Commande pour arrêter la musique
@bot.command()
async def stop(ctx):
    """Arrête la musique."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Aucune musique en cours.")
        return
    ctx.voice_client.stop()
    await send_temporary_message(ctx, "⏹️ Musique arrêtée.")
# Commandes de modération
@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    """Bannit un utilisateur du serveur."""
    await member.ban(reason=reason)
    await send_temporary_message(ctx, f"✅ {member.display_name} a été banni.")

@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    """Expulse un utilisateur du serveur."""
    await member.kick(reason=reason)
    await send_temporary_message(ctx, f"✅ {member.display_name} a été expulsé.")

@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member, time=None):
    """Mute un utilisateur pour un temps donné."""
    # Trouver ou créer un rôle "Muted"
    muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not muted_role:
        # Créer le rôle s'il n'existe pas
        muted_role = await ctx.guild.create_role(name="Muted")
        # Configurer les permissions pour tous les canaux
        for channel in ctx.guild.channels:
            await channel.set_permissions(muted_role, speak=False, send_messages=False)
    
    await member.add_roles(muted_role)
    
    # Si un temps est spécifié, planifier le unmute
    if time:
        time_value = int(time[:-1])
        time_unit = time[-1]
        
        # Convertir le temps en secondes
        if time_unit.lower() == 's':
            seconds = time_value
        elif time_unit.lower() == 'm':
            seconds = time_value * 60
        elif time_unit.lower() == 'h':
            seconds = time_value * 3600
        elif time_unit.lower() == 'd':
            seconds = time_value * 86400
        else:
            seconds = 300  # Par défaut 5 minutes
        
        await send_temporary_message(ctx, f"✅ {member.display_name} a été mute pour {time}.")
        await asyncio.sleep(seconds)
        await member.remove_roles(muted_role)
        await send_temporary_message(ctx, f"✅ {member.display_name} a été unmute automatiquement.")
    else:
        await send_temporary_message(ctx, f"✅ {member.display_name} a été mute.")

@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    """Unmute un utilisateur."""
    muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not muted_role:
        await send_temporary_message(ctx, "❌ Le rôle Muted n'existe pas.")
        return
        
    await member.remove_roles(muted_role)
    await send_temporary_message(ctx, f"✅ {member.display_name} a été unmute.")

# Système d'avertissement
warnings = {}  # Dictionnaire pour stocker les avertissements {user_id: [warnings]}

@bot.command()
@commands.has_permissions(manage_messages=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    """Avertit un utilisateur."""
    if member.id not in warnings:
        warnings[member.id] = []
    
    if reason is None:
        reason = "Aucune raison spécifiée"
        
    warnings[member.id].append(reason)
    
    await send_temporary_message(ctx, f"⚠️ {member.display_name} a reçu un avertissement: {reason}")

@bot.command()
@commands.has_permissions(manage_messages=True)
async def warns(ctx, member: discord.Member):
    """Affiche les avertissements d'un utilisateur."""
    if member.id not in warnings or not warnings[member.id]:
        await send_temporary_message(ctx, f"✅ {member.display_name} n'a pas d'avertissements.")
        return
        
    embed = discord.Embed(title=f"Avertissements de {member.display_name}", color=discord.Color.orange())
    
    for i, warning in enumerate(warnings[member.id], 1):
        embed.add_field(name=f"Avertissement {i}", value=warning, inline=False)
        
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(manage_messages=True)
async def clearwarns(ctx, member: discord.Member):
    """Efface les avertissements d'un utilisateur."""
    if member.id not in warnings:
        await send_temporary_message(ctx, f"✅ {member.display_name} n'a pas d'avertissements.")
        return
        
    warnings[member.id] = []
    await send_temporary_message(ctx, f"✅ Les avertissements de {member.display_name} ont été effacés.")

@bot.command()
@commands.has_permissions(manage_channels=True)
async def lock(ctx, channel: discord.TextChannel = None):
    """Verrouille un salon en empêchant les messages."""
    channel = channel or ctx.channel
    await channel.set_permissions(ctx.guild.default_role, send_messages=False)
    await send_temporary_message(ctx, f"🔒 Le salon {channel.name} a été verrouillé.")

@bot.command()
@commands.has_permissions(manage_channels=True)
async def unlock(ctx, channel: discord.TextChannel = None):
    """Déverrouille un salon."""
    channel = channel or ctx.channel
    await channel.set_permissions(ctx.guild.default_role, send_messages=True)
    await send_temporary_message(ctx, f"🔓 Le salon {channel.name} a été déverrouillé.")

# Commandes Fun
@bot.command(name="ball8")
async def ball8(ctx, *, question=None):
    """Répond à une question avec une réponse de boule magique."""
    if question is None:
        await send_temporary_message(ctx, "❌ Vous devez poser une question.")
        return
        
    responses = [
        "C'est certain.", "C'est décidément ainsi.", "Sans aucun doute.", "Oui, définitivement.",
        "Vous pouvez compter dessus.", "Comme je le vois, oui.", "Très probablement.", "Bonnes perspectives.",
        "Oui.", "Les signes indiquent que oui.", "Réponse floue, réessayez.", "Reposez la question plus tard.",
        "Il vaut mieux ne pas vous le dire maintenant.", "Impossible de prédire maintenant.", "Concentrez-vous et redemandez.",
        "Ne comptez pas dessus.", "Ma réponse est non.", "Mes sources disent non.",
        "Les perspectives ne sont pas bonnes.", "Très douteux."
    ]
    
    response = random.choice(responses)
    embed = discord.Embed(title="🎱 Boule Magique", description=f"**Question:** {question}\n**Réponse:** {response}", color=discord.Color.blue())
    await ctx.send(embed=embed)

@bot.command()
async def say(ctx, *, message=None):
    """Fait répéter un message au bot."""
    if message is None:
        await send_temporary_message(ctx, "❌ Vous devez spécifier un message.")
        return
        
    await ctx.message.delete()  # Supprime la commande de l'utilisateur
    await ctx.send(message)

@bot.command()
async def reverse(ctx, *, message=None):
    """Renverse un message."""
    if message is None:
        await send_temporary_message(ctx, "❌ Vous devez spécifier un message.")
        return
        
    reversed_message = message[::-1]
    await ctx.send(f"🔄 **Message inversé:** {reversed_message}")

@bot.command()
async def dice(ctx):
    """Lance un dé à 6 faces."""
    result = random.randint(1, 6)
    await ctx.send(f"🎲 Vous avez lancé un **{result}**.")

@bot.command()
async def joke(ctx):
    """Envoie une blague aléatoire."""
    jokes = [
        "Pourquoi les plongeurs plongent-ils toujours en arrière et jamais en avant ? Parce que sinon ils tombent dans le bateau !",
        "Qu'est-ce qu'un crocodile qui surveille la pharmacie ? Un Lacoste garde !",
        "Que se passe-t-il quand 2 poissons s'énervent ? Le thon monte !",
        "Pourquoi les livres ont-ils toujours chaud ? Parce qu'ils ont une couverture !",
        "Comment appelle-t-on un chat tombé dans un pot de peinture le jour de Noël ? Un chat-peint de Noël !",
        "Pourquoi le football c'est rigolo ? Parce que Thierry en rit (Henry) !",
        "Quel est le comble pour un électricien ? De ne pas être au courant !",
        "Que dit une noisette quand elle tombe dans l'eau ? Je me noix !",
        "Quel est le fruit préféré des profs ? La pêche, car elle a un noyau !",
        "Qu'est-ce qui est petit, carré et jaune ? Un petit carré jaune !"
    ]
    
    joke = random.choice(jokes)
    await ctx.send(f"😂 **Blague:** {joke}")

@bot.command()
async def meme(ctx):
    """Envoie un mème aléatoire."""
    try:
        response = requests.get("https://meme-api.com/gimme")
        data = response.json()
        
        embed = discord.Embed(title=data["title"], url=data["postLink"], color=discord.Color.random())
        embed.set_image(url=data["url"])
        embed.set_footer(text=f"r/{data['subreddit']} | ⬆️ {data['ups']}")
        
        await ctx.send(embed=embed)
    except Exception as e:
        await send_temporary_message(ctx, f"❌ Erreur lors de la récupération du mème: {str(e)}")

@bot.command()
async def slap(ctx, member: discord.Member):
    """Donne une gifle virtuelle à un utilisateur."""
    gifs = [
        "https://media.giphy.com/media/Zau0yrl17uzdK/giphy.gif",
        "https://media.giphy.com/media/Gf3AUz3eBNbTW/giphy.gif",
        "https://media.giphy.com/media/uqSU9IEYEKAbS/giphy.gif",
        "https://media.giphy.com/media/jLeyZWgtwgr2U/giphy.gif",
        "https://media.giphy.com/media/RXGNsyRb1hDJm/giphy.gif"
    ]
    
    gif = random.choice(gifs)
    embed = discord.Embed(description=f"{ctx.author.mention} a giflé {member.mention} ! 👋", color=discord.Color.red())
    embed.set_image(url=gif)
    
    await ctx.send(embed=embed)

@bot.command()
async def choose(ctx, *options):
    """Choisit une option parmi une liste."""
    if len(options) < 2:
        await send_temporary_message(ctx, "❌ Vous devez proposer au moins 2 options.")
        return
        
    choice = random.choice(options)
    await ctx.send(f"🎯 J'ai choisi: **{choice}**")

@bot.command()
async def gif(ctx, *, search=None):
    """Envoie un GIF correspondant à une recherche."""
    if search is None:
        await send_temporary_message(ctx, "❌ Vous devez spécifier une recherche.")
        return
        
    try:
        response = requests.get(f"https://api.giphy.com/v1/gifs/search?api_key=pLURtkhVrUXr3KG25Gy5IvzziV5OrZGa&q={search}&limit=10")
        data = response.json()
        
        if not data["data"]:
            await send_temporary_message(ctx, f"❌ Aucun GIF trouvé pour '{search}'.")
            return
            
        gif_url = random.choice(data["data"])["images"]["original"]["url"]
        
        embed = discord.Embed(color=discord.Color.purple())
        embed.set_image(url=gif_url)
        
        await ctx.send(embed=embed)
    except Exception as e:
        await send_temporary_message(ctx, f"❌ Erreur lors de la récupération du GIF: {str(e)}")

@bot.command()
async def image(ctx, *, search=None):
    """Recherche et affiche une image correspondant à une recherche."""
    if search is None:
        await send_temporary_message(ctx, "❌ Vous devez spécifier une recherche.")
        return
    
    # Message temporaire pour indiquer que la recherche est en cours
    loading_msg = await ctx.send(f"🔍 Recherche d'images pour '{search}'...")
    
    # Essayer plusieurs sources d'images avec différentes API
    sources = [
        "google_custom_search",  # Nouvelle option plus fiable
        "pixabay",
        "unsplash_api", # API Unsplash plus fiable
        "pexels",
        "unsplash_direct",
        "picsum"  # Dernier recours (aléatoire)
    ]
    
    for source in sources:
        try:
            if source == "google_custom_search":
                # Option 0: Google Custom Search API (plus fiable mais limité à 100 requêtes/jour)
                # Utiliser un moteur de recherche Google Custom avec une clé API gratuite
                # Vous pouvez remplacer ces clés par les vôtres si nécessaire
                search_term = search.replace(" ", "+")
                google_api_key = "AIzaSyDqOcxlKuRMN8JvT-cYe_TsCCKzJIFv_YI"  # Clé API Google démo (limitée)
                cx = "f4bd59dbc99994aea"  # ID du moteur de recherche personnalisé Google démo
                
                google_url = f"https://www.googleapis.com/customsearch/v1?key={google_api_key}&cx={cx}&q={search_term}&searchType=image"
                response = requests.get(google_url)
                data = response.json()
                
                if "items" in data and len(data["items"]) > 0:
                    image_url = data["items"][0]["link"]
                    
                    embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                    embed.set_image(url=image_url)
                    embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Source: Google")
                    
                    await loading_msg.delete()
                    await ctx.send(embed=embed)
                    return
            
            elif source == "pixabay":
                # Option 1: Pixabay
                search_term = search.replace(" ", "+")
                # Utilise une clé API publique - remplacer par votre propre clé si vous en avez une
                pixabay_url = f"https://pixabay.com/api/?key=35942431-4cf10b167d3e3953a43fc6efe&q={search_term}&image_type=photo&safesearch=true"
                response = requests.get(pixabay_url)
                data = response.json()
                
                if data.get("hits") and len(data["hits"]) > 0:
                    image_url = data["hits"][0]["largeImageURL"]
                    
                    embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                    embed.set_image(url=image_url)
                    embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Source: Pixabay")
                    
                    await loading_msg.delete()
                    await ctx.send(embed=embed)
                    return
            
            elif source == "unsplash_api":
                # Option 2: API Unsplash (plus fiable)
                search_term = search.replace(" ", "%20")
                # Utilise une clé API publique - remplacer par votre propre clé si vous en avez une
                unsplash_api_url = f"https://api.unsplash.com/search/photos?query={search_term}&per_page=1&client_id=4z3ItVs5HiQwvxrXR4n2oqEXs4-JdVcdcWOb4m3FOic"
                response = requests.get(unsplash_api_url)
                data = response.json()
                
                if "results" in data and len(data["results"]) > 0:
                    image_url = data["results"][0]["urls"]["regular"]
                    
                    embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                    embed.set_image(url=image_url)
                    embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Source: Unsplash API")
                    
                    await loading_msg.delete()
                    await ctx.send(embed=embed)
                    return
            
            elif source == "pexels":
                # Option 3: Pexels
                search_term = search.replace(" ", "%20")
                # Utilise une clé API publique - remplacer par votre propre clé si vous en avez une
                pexels_url = f"https://api.pexels.com/v1/search?query={search_term}&per_page=1"
                headers = {"Authorization": "563492ad6f917000010000010644870e02c143e9a0fbf5497d90d72a"}
                
                response = requests.get(pexels_url, headers=headers)
                data = response.json()
                
                if "photos" in data and len(data["photos"]) > 0:
                    image_url = data["photos"][0]["src"]["large"]
                    
                    embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                    embed.set_image(url=image_url)
                    embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Source: Pexels")
                    
                    await loading_msg.delete()
                    await ctx.send(embed=embed)
                    return
            
            elif source == "unsplash_direct":
                # Option 4: Unsplash directe (méthode de secours car parfois peu fiable)
                search_term = search.replace(" ", "-")
                timestamp = random.randint(1000000, 9999999)  # Évite la mise en cache
                unsplash_url = f"https://source.unsplash.com/featured/1200x800/?{search_term}&t={timestamp}"
                
                response = requests.get(unsplash_url, allow_redirects=True)
                final_url = response.url
                
                if response.status_code == 200 and "source.unsplash.com" not in final_url:
                    embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                    embed.set_image(url=final_url)
                    embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Source: Unsplash")
                    
                    await loading_msg.delete()
                    await ctx.send(embed=embed)
                    return
            
            elif source == "picsum":
                # Option 5: Image aléatoire (dernier recours)
                # Utilise le terme de recherche comme graine pour la génération aléatoire
                seed = ''.join(c for c in search if c.isalnum())
                if not seed:
                    seed = str(random.randint(1, 1000))
                picsum_url = f"https://picsum.photos/seed/{seed}/800/600"
                
                embed = discord.Embed(title=f"🖼️ Image pour '{search}'", color=discord.Color.blue())
                embed.set_image(url=picsum_url)
                embed.set_footer(text=f"Demandé par {ctx.author.display_name} | Image aléatoire")
                
                await loading_msg.delete()
                await ctx.send(embed=embed)
                # Informer que c'est une image aléatoire
                await ctx.send(f"⚠️ Pas d'image spécifique trouvée pour '{search}', voici une image aléatoire à la place.")
                return
                
        except Exception as e:
            print(f"Erreur avec la source {source}: {str(e)}")
            continue  # Essayer la source suivante
    
    # Si toutes les sources ont échoué
    await loading_msg.delete()
    await ctx.send(f"❌ Aucune image trouvée pour '{search}'.")

# Commandes Info
@bot.command()
async def serverinfo(ctx):
    """Affiche des informations sur le serveur."""
    guild = ctx.guild
    
    # Compteur de membres par statut
    online = sum(1 for m in guild.members if m.status == discord.Status.online)
    idle = sum(1 for m in guild.members if m.status == discord.Status.idle)
    dnd = sum(1 for m in guild.members if m.status == discord.Status.dnd)
    offline = sum(1 for m in guild.members if m.status == discord.Status.offline)
    
    # Compteur de canaux
    text_channels = len(guild.text_channels)
    voice_channels = len(guild.voice_channels)
    categories = len(guild.categories)
    
    # Créer l'embed
    embed = discord.Embed(title=f"Informations sur {guild.name}", color=guild.me.color)
    embed.set_thumbnail(url=guild.icon.url if guild.icon else None)
    
    embed.add_field(name="ID", value=guild.id, inline=True)
    embed.add_field(name="Propriétaire", value=guild.owner.mention, inline=True)
    embed.add_field(name="Région", value=str(guild.region) if hasattr(guild, "region") else "N/A", inline=True)
    
    embed.add_field(name="Créé le", value=guild.created_at.strftime("%d/%m/%Y"), inline=True)
    embed.add_field(name="Membres", value=guild.member_count, inline=True)
    embed.add_field(name="Rôles", value=len(guild.roles), inline=True)
    
    embed.add_field(name="Canaux", value=f"📝 {text_channels} | 🔊 {voice_channels} | 📂 {categories}", inline=True)
    embed.add_field(name="Emojis", value=len(guild.emojis), inline=True)
    embed.add_field(name="Niveau de Boost", value=f"Niveau {guild.premium_tier} ({guild.premium_subscription_count} boosts)", inline=True)
    
    embed.add_field(name="Statuts", value=f"🟢 {online} | 🟠 {idle} | 🔴 {dnd} | ⚫ {offline}", inline=True)
    
    await ctx.send(embed=embed)

@bot.command()
async def userinfo(ctx, member: discord.Member = None):
    """Affiche des informations sur un utilisateur."""
    member = member or ctx.author
    
    roles = [role.mention for role in member.roles if role.name != "@everyone"]
    
    embed = discord.Embed(color=member.color)
    embed.set_author(name=f"Informations sur {member}", icon_url=member.avatar.url if member.avatar else None)
    embed.set_thumbnail(url=member.avatar.url if member.avatar else None)
    
    embed.add_field(name="ID", value=member.id, inline=True)
    embed.add_field(name="Surnom", value=member.display_name, inline=True)
    embed.add_field(name="Compte créé le", value=member.created_at.strftime("%d/%m/%Y"), inline=True)
    
    embed.add_field(name="A rejoint le", value=member.joined_at.strftime("%d/%m/%Y"), inline=True)
    embed.add_field(name="Top Rôle", value=member.top_role.mention, inline=True)
    embed.add_field(name="Bot", value="Oui" if member.bot else "Non", inline=True)
    
    if roles:
        embed.add_field(name=f"Rôles ({len(roles)})", value=" ".join(roles) if len(" ".join(roles)) < 1024 else "Trop de rôles pour être affichés", inline=False)
    
    await ctx.send(embed=embed)

start_time = None

@bot.event
async def on_ready():
    global start_time
    start_time = discord.utils.utcnow()
    print(f'Connecté en tant que {bot.user}')

@bot.command()
async def uptime(ctx):
    """Affiche depuis combien de temps le bot est en ligne."""
    if start_time is None:
        await send_temporary_message(ctx, "❌ Le bot n'a pas encore démarré complètement.")
        return
        
    current_time = discord.utils.utcnow()
    delta = current_time - start_time
    
    days = delta.days
    hours, remainder = divmod(delta.seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    
    uptime_str = f"{days} jours, {hours} heures, {minutes} minutes et {seconds} secondes"
    
    embed = discord.Embed(title="⏰ Uptime", description=f"Je suis en ligne depuis:\n**{uptime_str}**", color=discord.Color.green())
    await ctx.send(embed=embed)

@bot.command()
async def ping(ctx):
    """Affiche la latence du bot."""
    latency = round(bot.latency * 1000)
    
    if latency < 100:
        color = discord.Color.green()
        status = "Excellente"
    elif latency < 200:
        color = discord.Color.gold()
        status = "Bonne"
    else:
        color = discord.Color.red()
        status = "Médiocre"
    
    embed = discord.Embed(title="🏓 Pong!", description=f"Latence: **{latency}ms**\nStatut: **{status}**", color=color)
    await ctx.send(embed=embed)

@bot.command()
async def date(ctx):
    """Affiche la date et l'heure actuelles."""
    now = discord.utils.utcnow()
    paris_time = now.astimezone(asyncio.get_event_loop().create_task(asyncio.to_thread(lambda: __import__('pytz').timezone('Europe/Paris'))).result())
    
    date_str = paris_time.strftime("%A %d %B %Y")
    time_str = paris_time.strftime("%H:%M:%S")
    
    embed = discord.Embed(title="📅 Date et Heure", color=discord.Color.blue())
    embed.add_field(name="Date", value=date_str, inline=False)
    embed.add_field(name="Heure", value=time_str, inline=False)
    
    await ctx.send(embed=embed)

@bot.command()
async def poll(ctx, *, question=None):
    """Crée un sondage."""
    if question is None:
        await send_temporary_message(ctx, "❌ Vous devez spécifier une question.")
        return
        
    embed = discord.Embed(title="📊 Sondage", description=question, color=discord.Color.blue())
    embed.set_footer(text=f"Sondage créé par {ctx.author.display_name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
    
    poll_msg = await ctx.send(embed=embed)
    await poll_msg.add_reaction("👍")
    await poll_msg.add_reaction("👎")
    await poll_msg.add_reaction("🤷")

# Commandes d'utilitaire
@bot.command()
async def remindme(ctx, time=None, *, reminder=None):
    """Définit un rappel après un certain temps."""
    if time is None or reminder is None:
        await send_temporary_message(ctx, "❌ Utilisation: `+remindme [temps] [message]`")
        return
        
    # Convertir le temps en secondes
    time_value = int(time[:-1])
    time_unit = time[-1]
    
    if time_unit.lower() == 's':
        seconds = time_value
        time_str = f"{time_value} secondes"
    elif time_unit.lower() == 'm':
        seconds = time_value * 60
        time_str = f"{time_value} minutes"
    elif time_unit.lower() == 'h':
        seconds = time_value * 3600
        time_str = f"{time_value} heures"
    elif time_unit.lower() == 'd':
        seconds = time_value * 86400
        time_str = f"{time_value} jours"
    else:
        await send_temporary_message(ctx, "❌ Format de temps invalide. Utilisez s, m, h ou d.")
        return
    
    await send_temporary_message(ctx, f"✅ Je vous rappellerai dans {time_str}: {reminder}")
    
    # Attendre le temps spécifié
    await asyncio.sleep(seconds)
    
    # Envoyer le rappel
    embed = discord.Embed(title="⏰ Rappel", description=reminder, color=discord.Color.gold())
    await ctx.author.send(embed=embed)
    await ctx.send(f"{ctx.author.mention}, voici votre rappel!", embed=embed)

@bot.command()
async def timer(ctx, time=None):
    """Démarre un minuteur."""
    if time is None:
        await send_temporary_message(ctx, "❌ Utilisation: `+timer [temps]`")
        return
        
    # Convertir le temps en secondes
    time_value = int(time[:-1])
    time_unit = time[-1]
    
    if time_unit.lower() == 's':
        seconds = time_value
        time_str = f"{time_value} secondes"
    elif time_unit.lower() == 'm':
        seconds = time_value * 60
        time_str = f"{time_value} minutes"
    elif time_unit.lower() == 'h':
        seconds = time_value * 3600
        time_str = f"{time_value} heures"
    else:
        await send_temporary_message(ctx, "❌ Format de temps invalide. Utilisez s, m ou h.")
        return
    
    embed = discord.Embed(title="⏱️ Minuteur", description=f"Minuteur démarré pour {time_str}.", color=discord.Color.blue())
    timer_msg = await ctx.send(embed=embed)
    
    # Mettre à jour le minuteur toutes les 5 secondes
    end_time = discord.utils.utcnow() + discord.utils.timedelta(seconds=seconds)
    
    while discord.utils.utcnow() < end_time:
        remaining = end_time - discord.utils.utcnow()
        remaining_seconds = remaining.total_seconds()
        
        # Calculer heures, minutes, secondes restantes
        hours, remainder = divmod(int(remaining_seconds), 3600)
        minutes, seconds_left = divmod(remainder, 60)
        
        if hours > 0:
            time_left = f"{hours}h {minutes}m {seconds_left}s"
        elif minutes > 0:
            time_left = f"{minutes}m {seconds_left}s"
        else:
            time_left = f"{seconds_left}s"
        
        embed.description = f"Temps restant: **{time_left}**"
        await timer_msg.edit(embed=embed)
        
        # Attendre 5 secondes ou le temps restant si < 5 secondes
        await asyncio.sleep(min(5, remaining_seconds))
    
    embed.description = "⏰ Le minuteur est terminé!"
    embed.color = discord.Color.green()
    await timer_msg.edit(embed=embed)
    await ctx.send(f"{ctx.author.mention}, votre minuteur de {time_str} est terminé!")

@bot.command()
async def translate(ctx, lang=None, *, text=None):
    """Traduit un texte dans la langue spécifiée."""
    if lang is None or text is None:
        await send_temporary_message(ctx, "❌ Utilisation: `+translate [langue] [texte]`")
        return
        
    try:
        translator = Translator()
        translation = translator.translate(text, dest=lang)
        
        embed = discord.Embed(title="🌍 Traduction", color=discord.Color.blue())
        embed.add_field(name=f"Texte original ({translation.src})", value=text, inline=False)
        embed.add_field(name=f"Traduction ({lang})", value=translation.text, inline=False)
        
        await ctx.send(embed=embed)
    except Exception as e:
        await send_temporary_message(ctx, f"❌ Erreur de traduction: {str(e)}")

# Commandes de musique supplémentaires
@bot.command()
async def pause(ctx):
    """Met en pause la musique en cours."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
        
    if not ctx.voice_client.is_playing():
        await send_temporary_message(ctx, "❌ Aucune musique en cours.")
        return
        
    ctx.voice_client.pause()
    await send_temporary_message(ctx, "⏸️ Musique mise en pause.")

@bot.command()
async def resume(ctx):
    """Reprend la lecture de la musique."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
        
    if not ctx.voice_client.is_paused():
        await send_temporary_message(ctx, "❌ La musique n'est pas en pause.")
        return
        
    ctx.voice_client.resume()
    await send_temporary_message(ctx, "▶️ Lecture reprise.")

@bot.command()
async def skip(ctx):
    """Passe à la musique suivante."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
        
    if not ctx.voice_client.is_playing():
        await send_temporary_message(ctx, "❌ Aucune musique en cours.")
        return
        
    ctx.voice_client.stop()
    await send_temporary_message(ctx, "⏭️ Musique suivante.")
    
@bot.command()
async def dm(ctx, member: discord.Member = None, *, message=None):
    """Envoie un message privé à un utilisateur."""
    if member is None or message is None:
        await send_temporary_message(ctx, "❌ Utilisation: `+dm [utilisateur] [message]`")
        return
    
    try:
        # Créer un embed pour le message
        embed = discord.Embed(
            title="📩 Nouveau message",
            description=message,
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"Envoyé par {ctx.author.display_name}", icon_url=ctx.author.avatar.url if ctx.author.avatar else None)
        
        # Envoyer le message privé
        await member.send(embed=embed)
        
        # Confirmer l'envoi
        await send_temporary_message(ctx, f"✅ Message envoyé à {member.display_name}.")
    except discord.Forbidden:
        await send_temporary_message(ctx, f"❌ Impossible d'envoyer un message à {member.display_name}. Leurs DMs sont peut-être fermés.")
    except Exception as e:
        await send_temporary_message(ctx, f"❌ Une erreur s'est produite: {str(e)}")

# File d'attente simplifiée pour la musique
song_queue = {}

@bot.command()
async def loop(ctx):
    """Active/désactive la lecture en boucle."""
    if ctx.voice_client is None:
        await send_temporary_message(ctx, "❌ Le bot n'est pas connecté à un canal vocal.")
        return
        
    if not hasattr(ctx.voice_client, "loop"):
        ctx.voice_client.loop = False
        
    ctx.voice_client.loop = not ctx.voice_client.loop
    await send_temporary_message(ctx, f"🔄 Lecture en boucle {'activée' if ctx.voice_client.loop else 'désactivée'}.")

# Lancer le bot
bot.run(os.environ['TOKEN_BOT_DISCORD'])